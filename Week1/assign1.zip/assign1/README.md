# NOTES
- I assumed that MSB is at qs[0]. So, a configuration of the form:

```
qs[0] = 1
qs[1] = 0
qs[2] = 1
```

represents the number `|101> = 5`.

So, the indexing of a qubit is of the form:
```
| qs[0] qs[1] qs[2] ... qs[n] > === qs[n] + qs[n-1]*2 + ... + qs[0]*2^n
```
